import React, { useRef } from 'react'
import './Testimonials.css'
import next_icon from '../../assets/next-icon.png'
import back_icon from '../../assets/back-icon.png'
import user_1 from '../../assets/user01.jpeg'
import user_2 from '../../assets/user02.jpeg'
import user_3 from '../../assets/user03.jpeg'
import user_4 from '../../assets/user04.jpeg'

const Testimonials = () => {

    const slider = useRef();
    let tx = 0;

const slideForward = ()=>{
    if(tx > -50){
        tx -= 25;
    }
    slider.current.style.transform = `translateX(${tx}%)`;
}
const slideBackward = ()=>{
    if(tx < 0){
        tx += 25;
    }
    slider.current.style.transform = `translateX(${tx}%)`;
}

  return (
    <div className='testimonials'>
      <img src={next_icon} alt="" className='next-btn' onClick={slideForward}/>
      <img src={back_icon} alt="" className='back-btn' onClick={slideBackward}/>
      <div className="slider">
        <ul ref={slider}>
            <li>
                <div className="slide">
                    <div className="user-info">
                        <img src={user_1} alt="" />
                        <div>
                            <h3>TOBY</h3>
                            <span>Hyderabad</span>
                        </div>
                    </div>
                    <p>Reedha Events exceeded all my expectations! The themed party they organized for my wife's 30th birthday was stunning. Great job, guys!</p>
                </div>
            </li>
            <li>
                <div className="slide">
                    <div className="user-info">
                        <img src={user_2} alt="" />
                        <div>
                            <h3>REESHMA</h3>
                            <span>Bangalore</span>
                        </div>
                    </div>
                    <p>I was blown away by the attention to detail and professionalism shown by Reedha Events. My son's 10th birthday party was a huge success! The kids had an absolute blast.</p>
                </div>
            </li>
            <li>
                <div className="slide">
                    <div className="user-info">
                        <img src={user_3} alt="" />
                        <div>
                            <h3>DIA</h3>
                            <span>Hyderabad</span>
                        </div>
                    </div>
                    <p>Reedha Events made planning my child's birthday party a breeze. Their creativity, expertise, and communication skills are exceptional. Highly recommend.</p>
                </div>
            </li>
            <li>
                <div className="slide">
                    <div className="user-info">
                        <img src={user_4} alt="" />
                        <div>
                            <h3>ROCKY</h3>
                            <span>Bangalore</span>
                        </div>
                    </div>
                    <p>Reedha Events truly made my daughter's 5th birthday party unforgettable! The decorations, food, and games were all top-notch. Highly recommend!.</p>
                </div>
            </li>
        </ul>
      </div>
    </div>
  )
}

export default Testimonials
