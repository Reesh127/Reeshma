import React from 'react'
import './About.css'
import about_img from '../../assets/aboutree.jpeg'
import play_icon from '../../assets/play-icon.png'

const About = ({setPlayState}) => {
  return (
    <div className='about'>
      <div className="about-left">
        <img src={about_img} alt="" className='about-img'/>
        <img src={play_icon} alt="" className='play-icon' onClick={()=>{setPlayState(true)}}/>
      </div>
      <div className="about-right">
        <h3>Intelligence + Fun = Your Cleverly Perfect Event- REEDHA EVENTS</h3>
        <h2>Unleash the fun, we'll handle the rest</h2>
        <p> “Let Us Plan Your Event You Just Bring the Smiles!”</p>
        <p>“Your Dream Event Starts Here  Get Ready to Shine!”</p>
      </div>
    </div>
  )
}

export default About
