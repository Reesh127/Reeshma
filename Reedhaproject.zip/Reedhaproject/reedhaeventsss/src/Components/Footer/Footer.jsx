import React from 'react'
import './Footer.css'

const Footer = () => {
  return (
    <div className='footer'>
      <p>@reedha_events</p>
    </div>
  )
}

export default Footer
