import React from 'react'
import './Hero.css'
import dark_arrow from '../../assets/dark-arrow.png'

const Hero = () => {
  return (
    <div className='hero container'>
      <div className="hero-text font-semibold">
        <h1>Welcome to REEDHA EVENTS your one-stop destination for turning every special moment into an unforgettable celebration!</h1>
        <p>Let us handle the stress while you enjoy the magic of your day</p>
        <button className='btn'>Explore more <img src={dark_arrow} alt="" /></button>
      </div>
    </div>
  )
}

export default Hero
